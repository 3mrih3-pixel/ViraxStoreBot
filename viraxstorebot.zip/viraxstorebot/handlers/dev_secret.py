# -*- coding: utf-8 -*-
"""
handlers/dev_secret.py
-----------------------
هاندلر خاص بمفتاح تجربة المطور (Developer Secret).
إذا أرسل أي مستخدم الكود السري حرفياً، يتم إضافة نقاط تجريبية له.
يمكن تعطيل هذه الميزة بالكامل من config.py عبر DEV_SECRET_ENABLED = False
"""

from telegram import Update
from telegram.ext import ContextTypes

from database import db
from config import DEV_SECRET_ENABLED, DEV_SECRET_CODE, DEV_SECRET_POINTS


async def dev_secret_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """يُستدعى فقط عندما تطابق الرسالة الكود السري تماماً (تتم إضافة الفلتر في main.py)."""
    if not DEV_SECRET_ENABLED:
        return  # الميزة معطّلة، لا تفعل شيء (لن يصل الطلب هنا أصلاً لو تم ضبط الفلتر بشكل صحيح)

    user = update.effective_user
    db.get_or_create_user(user.id, user.username or user.first_name or "")
    db.add_points(user.id, DEV_SECRET_POINTS)

    text = (
        "✅ تم تفعيل وضع المطور.\n"
        f"تم إضافة {DEV_SECRET_POINTS} نقطة."
    )
    await update.message.reply_text(text)
