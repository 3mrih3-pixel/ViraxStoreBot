# -*- coding: utf-8 -*-
"""
handlers/user.py
----------------
كل الهاندلرز الخاصة بالمستخدم العادي:
- البدء /start
- القائمة الرئيسية (المتجر / ربح النقاط / الهدية اليومية / رصيدي / المساعدة)
- عرض منتج معيّن وشراؤه
- الهدية اليومية
"""

import random
import datetime

from telegram import Update
from telegram.ext import ContextTypes

from database import db
from config import (
    BTN_SHOP, BTN_EARN, BTN_DAILY, BTN_PROFILE, BTN_HELP,
    DAILY_GIFT_MIN, DAILY_GIFT_MAX, DAILY_GIFT_COOLDOWN_HOURS,
)
from keyboards import (
    main_menu_keyboard, shop_list_keyboard, product_view_keyboard,
    purchase_confirm_keyboard, earn_points_keyboard,
)


# ---------------------------------------------------------------------------
# أدوات مساعدة
# ---------------------------------------------------------------------------

def _format_timedelta(delta: datetime.timedelta) -> str:
    """تنسيق الوقت المتبقي بشكل مقروء بالعربية."""
    total_seconds = int(delta.total_seconds())
    hours, remainder = divmod(total_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours} ساعة و {minutes} دقيقة و {seconds} ثانية"


def _ensure_user(update: Update):
    """التأكد من وجود المستخدم في قاعدة البيانات وإرجاع بياناته."""
    user = update.effective_user
    username = user.username or user.first_name or "بدون اسم"
    return db.get_or_create_user(user.id, username)


# ---------------------------------------------------------------------------
# أمر البدء /start
# ---------------------------------------------------------------------------

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _ensure_user(update)
    text = (
        "👋 أهلاً بك في متجر Virax!\n\n"
        "يمكنك جمع النقاط والحصول على منتجات مميزة (سكربتات / بانلات / أكواد).\n"
        "استخدم القائمة أدناه للتنقل 👇"
    )
    await update.message.reply_text(text, reply_markup=main_menu_keyboard())


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "ℹ️ *المساعدة*\n\n"
        "🛒 المتجر: تصفح المنتجات المتاحة وشراؤها بالنقاط.\n"
        "💰 ربح النقاط: طرق الحصول على نقاط إضافية.\n"
        "🎁 الهدية اليومية: احصل على نقاط مجانية كل 24 ساعة.\n"
        "👤 رصيدي: يعرض عدد نقاطك وعدد مشترياتك.\n"
    )
    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=main_menu_keyboard())


# ---------------------------------------------------------------------------
# رصيدي
# ---------------------------------------------------------------------------

async def profile_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_row = _ensure_user(update)
    text = (
        "👤 *معلومات حسابك*\n\n"
        f"💰 نقاطك: {user_row['points']}\n"
        f"🛍️ عدد مشترياتك: {user_row['purchases_count']}\n"
    )
    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=main_menu_keyboard())


# ---------------------------------------------------------------------------
# الهدية اليومية (منطق مشترك بين الزر في القائمة الرئيسية وزر Inline)
# ---------------------------------------------------------------------------

def _claim_daily_gift(user_id: int):
    """
    محاولة صرف الهدية اليومية.
    ترجع tuple: (نجح؟, رسالة النتيجة)
    """
    user_row = db.get_user(user_id)
    now = datetime.datetime.utcnow()

    if user_row["last_daily"]:
        last_daily = datetime.datetime.fromisoformat(user_row["last_daily"])
        elapsed = now - last_daily
        cooldown = datetime.timedelta(hours=DAILY_GIFT_COOLDOWN_HOURS)
        if elapsed < cooldown:
            remaining = cooldown - elapsed
            msg = (
                "⏳ لقد حصلت على هديتك اليومية بالفعل.\n"
                f"الوقت المتبقي: {_format_timedelta(remaining)}"
            )
            return False, msg

    gift_amount = random.randint(DAILY_GIFT_MIN, DAILY_GIFT_MAX)
    db.add_points(user_id, gift_amount)
    db.update_last_daily(user_id, now.isoformat())

    msg = f"🎁 مبروك! لقد حصلت على {gift_amount} نقطة.\nعُد بعد 24 ساعة للحصول على هدية جديدة."
    return True, msg


async def daily_gift_message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """عند الضغط على زر الهدية اليومية في القائمة الرئيسية (Reply Keyboard)."""
    _ensure_user(update)
    _, msg = _claim_daily_gift(update.effective_user.id)
    await update.message.reply_text(msg, reply_markup=main_menu_keyboard())


# ---------------------------------------------------------------------------
# طرق ربح النقاط
# ---------------------------------------------------------------------------

async def earn_points_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _ensure_user(update)
    text = "💰 *طرق ربح النقاط المتاحة حالياً:*"
    await update.message.reply_text(
        text, parse_mode="Markdown", reply_markup=earn_points_keyboard()
    )


async def earn_points_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """التعامل مع الضغط على أزرار قائمة ربح النقاط (Inline)."""
    query = update.callback_query

    # ملاحظة: يجب استدعاء query.answer() مرة واحدة فقط لكل ضغطة زر
    if query.data == "earn_daily":
        await query.answer()
        _, msg = _claim_daily_gift(query.from_user.id)
        await query.message.reply_text(msg, reply_markup=main_menu_keyboard())
    else:
        # أزرار "قريباً"
        await query.answer("🔒 هذه الميزة غير متاحة بعد، تابعنا قريباً!", show_alert=True)


# ---------------------------------------------------------------------------
# المتجر
# ---------------------------------------------------------------------------

async def shop_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """عرض قائمة المنتجات عند الضغط على زر المتجر."""
    _ensure_user(update)
    products = db.get_all_products()

    if not products:
        await update.message.reply_text(
            "🛒 المتجر فارغ حالياً، عد لاحقاً!", reply_markup=main_menu_keyboard()
        )
        return

    await update.message.reply_text(
        "🛒 *منتجات المتجر المتاحة:*",
        parse_mode="Markdown",
        reply_markup=shop_list_keyboard(products),
    )


async def shop_back_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """الرجوع لقائمة المتجر من صفحة عرض منتج."""
    query = update.callback_query
    await query.answer()
    products = db.get_all_products()

    if not products:
        await query.edit_message_text("🛒 المتجر فارغ حالياً، عد لاحقاً!")
        return

    await query.edit_message_text(
        "🛒 منتجات المتجر المتاحة:",
        reply_markup=shop_list_keyboard(products),
    )


async def product_view_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """عرض تفاصيل منتج معين عند الضغط عليه من القائمة."""
    query = update.callback_query
    await query.answer()

    product_id = int(query.data.split(":")[1])
    product = db.get_product(product_id)

    if product is None:
        await query.edit_message_text("❌ هذا المنتج لم يعد متوفراً.")
        return

    text = (
        f"📦 *{product['name']}*\n\n"
        f"📝 الوصف: {product['description']}\n"
        f"🏷️ النوع: {product['product_type']}\n"
        f"💰 السعر: {product['price']} نقطة\n"
    )
    await query.edit_message_text(
        text, parse_mode="Markdown", reply_markup=product_view_keyboard(product_id)
    )


async def buy_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """الضغط على زر (شراء) - يعرض تأكيد الشراء أو رسالة رفض."""
    query = update.callback_query

    user_id = query.from_user.id
    product_id = int(query.data.split(":")[1])

    product = db.get_product(product_id)
    if product is None:
        await query.answer()
        await query.edit_message_text("❌ هذا المنتج لم يعد متوفراً.")
        return

    # التحقق من عدم الشراء المسبق (إلا إذا كان الأدمن يسمح بإعادة الشراء)
    if not product["allow_repurchase"] and db.has_purchased(user_id, product_id):
        await query.answer("⚠️ لقد اشتريت هذا المنتج من قبل.", show_alert=True)
        return

    user_row = db.get_user(user_id)
    if user_row["points"] < product["price"]:
        await query.answer("❌ ليس لديك نقاط كافية.", show_alert=True)
        return

    # ملاحظة: query.answer() يُستدعى مرة واحدة فقط لكل ضغطة زر
    await query.answer()
    text = (
        "هل تريد شراء هذا المنتج؟\n\n"
        f"الاسم: {product['name']}\n"
        f"السعر: {product['price']} نقطة"
    )
    await query.edit_message_text(text, reply_markup=purchase_confirm_keyboard(product_id))


async def buy_confirm_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """تأكيد الشراء: خصم النقاط، إرسال المحتوى، وتسجيل عملية الشراء."""
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    product_id = int(query.data.split(":")[1])

    product = db.get_product(product_id)
    if product is None:
        await query.edit_message_text("❌ هذا المنتج لم يعد متوفراً.")
        return

    # إعادة التحقق من الشروط وقت التأكيد لتفادي أي تلاعب أو تأخير
    if not product["allow_repurchase"] and db.has_purchased(user_id, product_id):
        await query.edit_message_text("⚠️ لقد اشتريت هذا المنتج من قبل.")
        return

    user_row = db.get_user(user_id)
    if user_row["points"] < product["price"]:
        await query.edit_message_text("❌ ليس لديك نقاط كافية.")
        return

    # تنفيذ عملية الشراء
    db.add_points(user_id, -product["price"])
    db.record_purchase(user_id, product_id)
    db.increment_purchases_count(user_id)

    await query.edit_message_text("✅ تمت عملية الشراء بنجاح! سيتم إرسال المنتج الآن.")

    delivery_text = (
        f"📦 *{product['name']}*\n\n"
        f"محتوى منتجك:\n\n{product['content']}"
    )
    await query.message.reply_text(delivery_text, parse_mode="Markdown")


async def buy_cancel_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """إلغاء عملية الشراء والرجوع لعرض المنتج."""
    query = update.callback_query
    await query.answer()

    product_id = int(query.data.split(":")[1])
    product = db.get_product(product_id)

    if product is None:
        await query.edit_message_text("❌ تم إلغاء العملية.")
        return

    text = (
        f"📦 *{product['name']}*\n\n"
        f"📝 الوصف: {product['description']}\n"
        f"🏷️ النوع: {product['product_type']}\n"
        f"💰 السعر: {product['price']} نقطة\n"
    )
    await query.edit_message_text(
        text, parse_mode="Markdown", reply_markup=product_view_keyboard(product_id)
    )
