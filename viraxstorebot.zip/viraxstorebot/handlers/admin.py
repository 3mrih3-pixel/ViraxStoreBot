# -*- coding: utf-8 -*-
"""
handlers/admin.py
------------------
كل أوامر لوحة تحكم الأدمن:
- إضافة / حذف منتج
- تعديل السعر / المحتوى
- إضافة / خصم نقاط لمستخدم
- عرض جميع المستخدمين
- إحصائيات عامة
- السماح/منع إعادة شراء منتج معين

كل الأوامر تعتمد على الفاصلة العمودية "|" لفصل الحقول التي قد تحتوي مسافات،
لتسهيل الكتابة من الهاتف (Pydroid / تيليجرام موبايل).
"""

from telegram import Update
from telegram.ext import ContextTypes

from database import db
from config import ADMIN_IDS


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


async def _reject_non_admin(update: Update) -> bool:
    """يرجع True إذا تم رفض الطلب لعدم كون المستخدم أدمن."""
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ هذا الأمر مخصص للأدمن فقط.")
        return True
    return False


# ---------------------------------------------------------------------------
# إدارة المنتجات
# ---------------------------------------------------------------------------

async def add_product_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    الاستخدام:
    /addproduct الاسم|الوصف|السعر|النوع|المحتوى
    مثال:
    /addproduct بوت اختراق تجريبي|سكربت بسيط للتجربة|50|Script|هذا هو الكود السري هنا
    """
    if await _reject_non_admin(update):
        return

    raw_text = update.message.text.partition(" ")[2]  # كل شيء بعد الأمر
    parts = raw_text.split("|")

    if len(parts) < 5:
        await update.message.reply_text(
            "⚠️ صيغة غير صحيحة.\n\n"
            "الاستخدام:\n"
            "/addproduct الاسم|الوصف|السعر|النوع|المحتوى"
        )
        return

    name, description, price_str, product_type, content = (
        parts[0].strip(),
        parts[1].strip(),
        parts[2].strip(),
        parts[3].strip(),
        "|".join(parts[4:]).strip(),  # المحتوى قد يحتوي فواصل إضافية
    )

    if not price_str.isdigit():
        await update.message.reply_text("⚠️ السعر يجب أن يكون رقماً صحيحاً.")
        return

    product_id = db.add_product(name, description, int(price_str), product_type, content)
    await update.message.reply_text(f"✅ تم إضافة المنتج بنجاح. آيدي المنتج: {product_id}")


async def delete_product_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """الاستخدام: /delproduct <id>"""
    if await _reject_non_admin(update):
        return

    if not context.args or not context.args[0].isdigit():
        await update.message.reply_text("⚠️ الاستخدام: /delproduct <آيدي المنتج>")
        return

    product_id = int(context.args[0])
    success = db.delete_product(product_id)
    if success:
        await update.message.reply_text(f"✅ تم حذف المنتج رقم {product_id}.")
    else:
        await update.message.reply_text("❌ لم يتم العثور على هذا المنتج.")


async def edit_price_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """الاستخدام: /editprice <id> <new_price>"""
    if await _reject_non_admin(update):
        return

    if len(context.args) < 2 or not all(a.isdigit() for a in context.args[:2]):
        await update.message.reply_text("⚠️ الاستخدام: /editprice <آيدي المنتج> <السعر الجديد>")
        return

    product_id, new_price = int(context.args[0]), int(context.args[1])
    success = db.update_product_price(product_id, new_price)
    if success:
        await update.message.reply_text(f"✅ تم تعديل سعر المنتج رقم {product_id} إلى {new_price} نقطة.")
    else:
        await update.message.reply_text("❌ لم يتم العثور على هذا المنتج.")


async def edit_content_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    الاستخدام:
    /editcontent <id>|المحتوى الجديد
    مثال:
    /editcontent 3|هذا هو الكود الجديد للمنتج
    """
    if await _reject_non_admin(update):
        return

    raw_text = update.message.text.partition(" ")[2]
    parts = raw_text.split("|", 1)

    if len(parts) < 2 or not parts[0].strip().isdigit():
        await update.message.reply_text(
            "⚠️ الاستخدام:\n/editcontent آيدي_المنتج|المحتوى الجديد"
        )
        return

    product_id = int(parts[0].strip())
    new_content = parts[1].strip()

    success = db.update_product_content(product_id, new_content)
    if success:
        await update.message.reply_text(f"✅ تم تعديل محتوى المنتج رقم {product_id}.")
    else:
        await update.message.reply_text("❌ لم يتم العثور على هذا المنتج.")


async def toggle_repurchase_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """الاستخدام: /allowrebuy <id> - يبدّل السماح بإعادة شراء المنتج."""
    if await _reject_non_admin(update):
        return

    if not context.args or not context.args[0].isdigit():
        await update.message.reply_text("⚠️ الاستخدام: /allowrebuy <آيدي المنتج>")
        return

    product_id = int(context.args[0])
    new_value = db.toggle_allow_repurchase(product_id)

    if new_value is None:
        await update.message.reply_text("❌ لم يتم العثور على هذا المنتج.")
    elif new_value:
        await update.message.reply_text(f"✅ أصبح يُسمح بإعادة شراء المنتج رقم {product_id}.")
    else:
        await update.message.reply_text(f"✅ لم يعد يُسمح بإعادة شراء المنتج رقم {product_id}.")


async def list_products_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """عرض جميع المنتجات مع آيديهم (مفيد للأدمن قبل التعديل أو الحذف)."""
    if await _reject_non_admin(update):
        return

    products = db.get_all_products()
    if not products:
        await update.message.reply_text("🛒 لا توجد منتجات حالياً.")
        return

    lines = ["🛒 *قائمة المنتجات:*\n"]
    for p in products:
        lines.append(
            f"🆔 {p['product_id']} | {p['name']} | {p['price']} نقطة | "
            f"{p['product_type']} | إعادة شراء: {'مسموح' if p['allow_repurchase'] else 'ممنوع'}"
        )
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


# ---------------------------------------------------------------------------
# إدارة نقاط المستخدمين
# ---------------------------------------------------------------------------

async def add_points_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """الاستخدام: /addpoints <user_id> <amount>"""
    if await _reject_non_admin(update):
        return

    if len(context.args) < 2 or not context.args[1].lstrip("-").isdigit():
        await update.message.reply_text("⚠️ الاستخدام: /addpoints <آيدي المستخدم> <عدد النقاط>")
        return

    target_id, amount = int(context.args[0]), int(context.args[1])
    user_row = db.get_user(target_id)

    if user_row is None:
        await update.message.reply_text("❌ هذا المستخدم غير مسجل في البوت بعد.")
        return

    db.add_points(target_id, amount)
    await update.message.reply_text(f"✅ تم إضافة {amount} نقطة للمستخدم {target_id}.")


async def remove_points_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """الاستخدام: /delpoints <user_id> <amount>"""
    if await _reject_non_admin(update):
        return

    if len(context.args) < 2 or not context.args[1].isdigit():
        await update.message.reply_text("⚠️ الاستخدام: /delpoints <آيدي المستخدم> <عدد النقاط>")
        return

    target_id, amount = int(context.args[0]), int(context.args[1])
    user_row = db.get_user(target_id)

    if user_row is None:
        await update.message.reply_text("❌ هذا المستخدم غير مسجل في البوت بعد.")
        return

    db.add_points(target_id, -amount)
    await update.message.reply_text(f"✅ تم خصم {amount} نقطة من المستخدم {target_id}.")


# ---------------------------------------------------------------------------
# عرض المستخدمين والإحصائيات
# ---------------------------------------------------------------------------

async def list_users_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await _reject_non_admin(update):
        return

    users = db.get_all_users()
    if not users:
        await update.message.reply_text("لا يوجد مستخدمون مسجلون بعد.")
        return

    lines = ["👥 *قائمة المستخدمين:*\n"]
    for u in users[:100]:  # حماية من الرسائل الطويلة جداً
        uname = u["username"] or "بدون يوزر"
        lines.append(
            f"🆔 {u['user_id']} | @{uname} | 💰 {u['points']} | 🛍️ {u['purchases_count']}"
        )

    if len(users) > 100:
        lines.append(f"\n... و {len(users) - 100} مستخدم آخر.")

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await _reject_non_admin(update):
        return

    stats = db.get_stats()
    text = (
        "📊 *إحصائيات البوت*\n\n"
        f"👥 عدد المستخدمين: {stats['users_count']}\n"
        f"🛒 عدد المنتجات: {stats['products_count']}\n"
        f"🧾 عدد عمليات الشراء: {stats['purchases_count']}\n"
        f"💰 إجمالي النقاط في النظام: {stats['total_points']}\n"
    )
    await update.message.reply_text(text, parse_mode="Markdown")


async def admin_help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """عرض قائمة كل أوامر الأدمن المتاحة."""
    if await _reject_non_admin(update):
        return

    text = (
        "🛠️ *أوامر لوحة تحكم الأدمن*\n\n"
        "➕ إضافة منتج:\n"
        "`/addproduct الاسم|الوصف|السعر|النوع|المحتوى`\n\n"
        "🗑️ حذف منتج:\n"
        "`/delproduct آيدي_المنتج`\n\n"
        "💵 تعديل السعر:\n"
        "`/editprice آيدي_المنتج السعر_الجديد`\n\n"
        "📝 تعديل المحتوى:\n"
        "`/editcontent آيدي_المنتج|المحتوى الجديد`\n\n"
        "🔁 تبديل السماح بإعادة الشراء:\n"
        "`/allowrebuy آيدي_المنتج`\n\n"
        "📋 عرض المنتجات:\n"
        "`/listproducts`\n\n"
        "➕ إضافة نقاط:\n"
        "`/addpoints آيدي_المستخدم عدد_النقاط`\n\n"
        "➖ خصم نقاط:\n"
        "`/delpoints آيدي_المستخدم عدد_النقاط`\n\n"
        "👥 عرض جميع المستخدمين:\n"
        "`/listusers`\n\n"
        "📊 الإحصائيات:\n"
        "`/stats`"
    )
    await update.message.reply_text(text, parse_mode="Markdown")
